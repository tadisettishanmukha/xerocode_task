module.exports = {
  host: "smtp.gmail.com",
  port: 465,
  username: "example@gmail.com",
  password: "belugas",
};
