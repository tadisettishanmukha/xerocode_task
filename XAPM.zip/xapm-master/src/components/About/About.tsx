import React from "react";

import XAPM from "../../../assets/xapm.png";
import styles from "./About.module.scss";

const About = () => {
  return (
    <div className={styles.wrapper}>
      <a href="https://xerocodee.com/">
        <img
          className={styles.logo}
          src={XAPM}
          alt="footer-product-logo"
        />
      </a>
      <div className={styles.section}>
        <h2>XAPM</h2>
        <p>
          Greetings, fellow space traveler! We&apos;re thrilled that you&apos;ve
          chosen our application to help you navigate and explore the vast
          universe of Docker infrastructure. As a XAPM, you know that
          real-time tracking of metrics and logs is essential for staying ahead
          of potential issues and optimizing your workflows.<p></p>
          Our application provides you with the tools you need to take control
          of your Docker images, containers, volumes, and logs, along with the
          tools to view your Kubernetes cluster metrics. With an intuitive
          interface, you can easily make the necessary adjustments to ensure a
          smooth journey through the cosmos of your Docker environment.
        </p>
      </div>
      <div className={styles.section}>
        <h2>OUR TEAM</h2>
        <p>
          As a team of passionate engineers, we are dedicated to improving the
          workflow of developers as they explore the vast universe of Docker
          infrastructure. We know that space travel can be complex and
          challenging, but with the right tools and support, you can navigate
          the stars with ease.
          <p></p>
          Our mission is to provide XAPM like you with the tools and
          support you need to make your Docker journey as smooth as possible. We
          strive to make our application intuitive, powerful, and user-friendly
          so that you can focus on exploring the Docker universe without
          worrying about the technical details.
        </p>
      </div>
      <div className={styles.section}>
        <h2>CONTACT US</h2>
        <p>
          We would love to hear your feedback and answer any questions you may
          have about our application. To get in touch with us, you can find us
          on LinkedIn and GitHub or send us an email. We&apos;re happy to chat
          with you about how our application can improve your workflow with
          Docker.
        </p>
      </div>
      <footer className={styles.footer}>
        <a className={styles.footerIcons} href="">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="32"
            height="32"
            viewBox="0 0 24 24"
            className="fill-current"
          >
            <path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z" />
          </svg>
        </a>

        <a className={styles.footerIcons} href="">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="42"
            height="42"
            fill="white"
            className="bi bi-envelope-at-fill"
            viewBox="0 0 24 24"
          >
            <path d="M2 2A2 2 0 0 0 .05 3.555L8 8.414l7.95-4.859A2 2 0 0 0 14 2H2Zm-2 9.8V4.698l5.803 3.546L0 11.801Zm6.761-2.97-6.57 4.026A2 2 0 0 0 2 14h6.256A4.493 4.493 0 0 1 8 12.5a4.49 4.49 0 0 1 1.606-3.446l-.367-.225L8 9.586l-1.239-.757ZM16 9.671V4.697l-5.803 3.546.338.208A4.482 4.482 0 0 1 12.5 8c1.414 0 2.675.652 3.5 1.671Z" />
            <path d="M15.834 12.244c0 1.168-.577 2.025-1.587 2.025-.503 0-1.002-.228-1.12-.648h-.043c-.118.416-.543.643-1.015.643-.77 0-1.259-.542-1.259-1.434v-.529c0-.844.481-1.4 1.26-1.4.585 0 .87.333.953.63h.03v-.568h.905v2.19c0 .272.18.42.411.42.315 0 .639-.415.639-1.39v-.118c0-1.277-.95-2.326-2.484-2.326h-.04c-1.582 0-2.64 1.067-2.64 2.724v.157c0 1.867 1.237 2.654 2.57 2.654h.045c.507 0 .935-.07 1.18-.18v.731c-.219.1-.643.175-1.237.175h-.044C10.438 16 9 14.82 9 12.646v-.214C9 10.36 10.421 9 12.485 9h.035c2.12 0 3.314 1.43 3.314 3.034v.21Zm-4.04.21v.227c0 .586.227.8.581.8.31 0 .564-.17.564-.743v-.367c0-.516-.275-.708-.572-.708-.346 0-.573.245-.573.791Z" />
          </svg>
        </a>

        <a className={styles.footerIcons} href="">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="32"
            height="32"
            viewBox="0 0 24 24"
            className="fill-current"
          >
            <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z" />
          </svg>
        </a>
      </footer>
    </div>
  );
};

export default About;
