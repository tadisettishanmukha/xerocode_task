/* eslint-disable react/prop-types */
import React from "react";
import { ContainerType } from "../../../types";
import { useAppSelector, useAppDispatch } from "../../reducers/hooks";
import useHelper from "../../helpers/commands";
import { createAlert, createPrompt } from "../../reducers/alertReducer";

import styles from "./Containers.module.scss";
import ContainersCard from "../ContainersCard/ContainersCard";

/**
 * @module | Containers.tsx
 * @description | Provides information and management over both running & stopped Docker containers
 **/

const Containers = (): JSX.Element => {
  const dispatch = useAppDispatch();

  const { runStopped, remove, stop } = useHelper();

  const { runningList, stoppedList } = useAppSelector(
    (state) => state.containers
  );

  const stopContainer = (container: ContainerType) => {
    dispatch(
      createPrompt(
        `Are you sure you want to stop ${container.Names}?`,
        () => {
          stop(container.ID);
          dispatch(createAlert(`Stopping ${container.Names}...`, 5, "error"));
        },
        () => {
          dispatch(
            createAlert(
              `The request to stop ${container.Names} has been cancelled.`,
              5,
              "warning"
            )
          );
        }
      )
    );
  };

  const runContainer = (container: ContainerType) => {
    dispatch(
      createPrompt(
        `Are you sure you want to run ${container.Names}?`,
        () => {
          runStopped(container["ID"]);
          dispatch(createAlert(`Running ${container.Names}...`, 5, "success"));
        },
        () => {
          dispatch(
            createAlert(
              `The request to run ${container.Names} has been cancelled.`,
              5,
              "warning"
            )
          );
        }
      )
    );
  };

  const removeContainer = (container: ContainerType) => {
    dispatch(
      createPrompt(
        `Are you sure you want to remove ${container.Names}?`,
        () => {
          remove(container["ID"]);
          dispatch(createAlert(`Removing ${container.Names}...`, 5, "success"));
        },
        () => {
          dispatch(
            createAlert(
              `The request to remove ${container.Names} has been cancelled.`,
              5,
              "warning"
            )
          );
        }
      )
    );
  };

  return (
    <div className={styles.wrapper}>
      <div className={styles.listHolder}>
        <h2>RUNNING CONTAINERS</h2>
        <p className={styles.count}>Count: {runningList.length}</p>
        <div className={styles.containerList}>
          <ContainersCard
            containerList={runningList}
            stopContainer={stopContainer}
            runContainer={runContainer}
            removeContainer={removeContainer}
            status="running"
          />
        </div>
      </div>
      <div className={styles.listHolder}>
        <h2>STOPPED CONTAINERS</h2>
        <p className={styles.count}>Count: {stoppedList.length}</p>
        <div className={styles.containerList}>
          <ContainersCard
            containerList={stoppedList}
            stopContainer={stopContainer}
            runContainer={runContainer}
            removeContainer={removeContainer}
            status="stopped"
          />
        </div>
      </div>
    </div>
  );
};

export default Containers;
